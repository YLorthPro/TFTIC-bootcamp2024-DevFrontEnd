import { Component } from '@angular/core';
import { StockService } from '../services/stock.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  stock!: StockService

  constructor(public _stock: StockService){
    _stock.elementStock(1)
    _stock.tailleStock
  }

}
