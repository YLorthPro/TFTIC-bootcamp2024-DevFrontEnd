import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StockService {

  stock: string[]=["lait", "patate","salade","Marc"]

  constructor() { }

  tailleStock(){
    console.log(this.stock.length)
  }

  elementStock(id: number){
    console.log(this.stock[id])
  }
}
