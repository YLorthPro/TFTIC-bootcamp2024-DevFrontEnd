import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './demo/home/home.component';
import { ContactComponent } from './demo/contact/contact.component';
import { BidingsComponent } from './demo/bidings/bidings.component';
import { DirectivesComponent } from './demo/directives/directives.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full'},
  { path: 'home', component: HomeComponent},
  { path : 'contact', component: ContactComponent},
  { path : 'bindings', component: BidingsComponent},
  { path : 'directives', component: DirectivesComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
